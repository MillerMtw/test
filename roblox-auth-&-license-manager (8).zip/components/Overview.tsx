
import React, { useMemo, useEffect, useState } from 'react';
import { Users, ShieldCheck, Zap, BarChart3, TrendingUp, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ExecutionLog, CredentialEntry } from '../types';

interface OverviewProps {
  logs: ExecutionLog[];
  users: CredentialEntry[];
  isOnline: boolean;
}

const Overview: React.FC<OverviewProps> = ({ logs, users, isOnline }) => {
  const [timeLeft, setTimeLeft] = useState('');
  const [historyRange, setHistoryRange] = useState<'7d' | '30d' | '90d'>('7d');

  const historyTitle = useMemo(() => {
    switch (historyRange) {
      case '7d': return '7 Days Executions';
      case '30d': return '1 Month Executions';
      case '90d': return '1 Year Executions';
      default: return 'Historial Graph';
    }
  }, [historyRange]);

  const stats = useMemo(() => {
    const now = Date.now();
    const lastReset = parseInt(localStorage.getItem('stats_last_reset') || '0');
    const dayMs = 24 * 60 * 60 * 1000;
    if (now - lastReset > dayMs) {
      localStorage.setItem('stats_last_reset', now.toString());
      localStorage.setItem('today_executions_offset', logs.length.toString());
    }
    const todayOffset = parseInt(localStorage.getItem('today_executions_offset') || '0');
    const todayCount = Math.max(0, logs.length - todayOffset);
    return { todayCount };
  }, [logs.length]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      const lastReset = parseInt(localStorage.getItem('stats_last_reset') || now.toString());
      const dayMs = 24 * 60 * 60 * 1000;
      const target = lastReset + dayMs;
      const diff = target - now;
      if (diff <= 0) {
        window.location.reload();
      } else {
        const h = Math.floor(diff / 3600000).toString().padStart(2, '0');
        const m = Math.floor((diff % 3600000) / 60000).toString().padStart(2, '0');
        const s = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
        setTimeLeft(`${h}:${m}:${s}`);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const activeNowCount = logs.filter(l => l.status === 'Authorized').length;

  const trafficData = useMemo(() => {
    const data = [];
    const now = new Date();
    for (let i = 23; i >= 0; i--) {
      const d = new Date(now.getTime() - i * 60 * 60 * 1000);
      let hour = d.getHours();
      const ampm = hour >= 12 ? 'PM' : 'AM';
      const hour12 = hour % 12 || 12;
      const label = `${hour12}${ampm}`;
      const windowStart = new Date(d);
      windowStart.setMinutes(0, 0, 0);
      const windowEnd = new Date(windowStart);
      windowEnd.setHours(windowEnd.getHours() + 1);
      const count = logs.filter(l => {
        const logTime = new Date(l.timestamp).getTime();
        return logTime >= windowStart.getTime() && logTime < windowEnd.getTime();
      }).length;
      data.push({ name: label, executions: count });
    }
    return data;
  }, [logs]);

  const historyGraphData = useMemo(() => {
    const data = [];
    const now = new Date();
    const daysToLookBack = historyRange === '7d' ? 7 : historyRange === '30d' ? 30 : 90;
    for (let i = daysToLookBack - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateString = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      const dayStart = new Date(d.setHours(0, 0, 0, 0)).getTime();
      const dayEnd = dayStart + 86400000;
      const count = logs.filter(l => {
        const t = new Date(l.timestamp).getTime();
        return t >= dayStart && t < dayEnd;
      }).length;
      data.push({ name: dateString, executions: count });
    }
    return data;
  }, [logs, historyRange]);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black uppercase text-white tracking-tighter">STATS DASHBOARD</h2>
          <p className="text-zinc-600 font-bold text-xs mt-1 uppercase tracking-widest">REAL-TIME MONITORING</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
        <MetricCard icon={<Zap className="w-5 h-5 text-red-500" />} label="Executions" value={stats.todayCount.toString()} sub="TODAY" delay="0" />
        <MetricCard icon={<Users className="w-5 h-5 text-blue-500" />} label="Clients" value={users.length.toString()} sub="VERIFIED CLIENTS" delay="100" />
        <MetricCard icon={<ShieldCheck className="w-5 h-5 text-emerald-500" />} label="Active Sessions" value={activeNowCount.toString()} sub="LIVE TRAFFIC" delay="200" />
      </div>

      <div className="bg-zinc-950/40 border border-white/5 rounded-[2.5rem] p-8 md:p-10 shadow-2xl relative overflow-hidden group backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-300">
        <div className="flex items-center justify-between mb-10 relative z-10">
          <div className="flex items-center gap-4">
             <div className="w-12 h-12 rounded-xl bg-black border border-white/5 flex items-center justify-center transition-all group-hover:scale-110 duration-500">
              <TrendingUp className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white uppercase tracking-normal">Stats Graph</h3>
              <p className="text-[10px] text-zinc-500 font-bold flex items-center gap-1 uppercase tracking-normal"><Clock className="w-3 h-3" /> Used Today</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <div className="px-4 py-1.5 bg-red-600/10 border border-red-500/20 rounded-full text-red-500 text-[10px] font-black uppercase tracking-normal">Today</div>
            <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-normal mr-2">Reset in: {timeLeft}</p>
          </div>
        </div>
        <div className="h-[300px] w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trafficData}>
              <defs>
                <linearGradient id="colorExec" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff0000" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#ff0000" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
              <XAxis dataKey="name" stroke="#444" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis stroke="#444" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ backgroundColor: '#050505', border: '1px solid #111', borderRadius: '12px', fontSize: '11px', color: '#fff', backdropFilter: 'blur(10px)' }} itemStyle={{ color: '#ff0000' }} />
              <Area type="monotone" dataKey="executions" stroke="#ff0000" fillOpacity={1} fill="url(#colorExec)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-zinc-950/40 border border-white/5 rounded-[2.5rem] shadow-2xl p-10 relative group backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-500">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-10 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-black border border-white/5 flex items-center justify-center transition-all group-hover:scale-110 duration-500">
              <BarChart3 className="w-6 h-6 text-red-600" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white uppercase tracking-normal">{historyTitle}</h3>
              <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-normal">Historial</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-black/40 p-1.5 rounded-xl border border-white/5">
            <button onClick={() => setHistoryRange('7d')} className={`px-4 py-2 rounded-lg text-[10px] font-bold transition-all duration-300 ${historyRange === '7d' ? 'bg-red-600 text-white shadow-xl' : 'text-zinc-600 hover:text-white'}`}>7 Days</button>
            <button onClick={() => setHistoryRange('30d')} className={`px-4 py-2 rounded-lg text-[10px] font-bold transition-all duration-300 ${historyRange === '30d' ? 'bg-red-600 text-white shadow-xl' : 'text-zinc-600 hover:text-white'}`}>1 Month</button>
            <button onClick={() => setHistoryRange('90d')} className={`px-4 py-2 rounded-lg text-[10px] font-bold transition-all duration-300 ${historyRange === '90d' ? 'bg-red-600 text-white shadow-xl' : 'text-zinc-600 hover:text-white'}`}>1 Year</button>
          </div>
        </div>
        <div className="h-[300px] w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={historyGraphData}>
              <defs>
                <linearGradient id="colorHist" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ff0000" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#ff0000" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
              <XAxis dataKey="name" stroke="#444" fontSize={10} tickLine={false} axisLine={false} />
              <YAxis stroke="#444" fontSize={10} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ backgroundColor: '#050505', border: '1px solid #111', borderRadius: '12px', fontSize: '11px', color: '#fff', backdropFilter: 'blur(10px)' }} />
              <Area type="monotone" dataKey="executions" stroke="#ff0000" fillOpacity={1} fill="url(#colorHist)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const MetricCard = ({ icon, label, value, sub, delay }: any) => (
  <div className={`bg-zinc-950/40 border border-white/5 p-8 rounded-[2.5rem] shadow-2xl hover:border-red-600/30 transition-all duration-500 group relative overflow-hidden backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-700`} style={{ animationDelay: `${delay}ms` }}>
    <div className="flex items-center gap-4 relative z-10">
      <div className="p-3 bg-black border border-white/5 rounded-xl group-hover:bg-red-600/10 transition-colors duration-500 group-hover:scale-110">{icon}</div>
      <div>
        <p className="text-zinc-500 text-xs font-bold uppercase tracking-normal">{label}</p>
        <p className="text-[10px] font-bold text-zinc-700 uppercase mt-0.5 tracking-normal">{sub}</p>
      </div>
    </div>
    <p className="text-5xl font-black text-white tracking-tighter mt-6 relative z-10 group-hover:translate-x-1 transition-transform duration-500">{value}</p>
  </div>
);

export default Overview;
