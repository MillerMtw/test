
import React, { useState } from 'react';
import { Filter, Download, Trash2, Search } from 'lucide-react';
import { AuthRequest } from '../types';

interface AuthLogsProps {
  logs: AuthRequest[];
}

const AuthLogs: React.FC<AuthLogsProps> = ({ logs }) => {
  const [filter, setFilter] = useState('');

  const filteredLogs = logs.filter(log => 
    log.username.toLowerCase().includes(filter.toLowerCase()) || 
    log.licencia.toLowerCase().includes(filter.toLowerCase()) ||
    log.key.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Authentication Logs</h1>
          <p className="text-slate-400">Audit trail of every remote request received.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors text-sm font-medium">
            <Download className="w-4 h-4" />
            Export CSV
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-rose-600/10 text-rose-400 hover:bg-rose-600/20 border border-rose-600/20 rounded-xl transition-colors text-sm font-medium">
            <Trash2 className="w-4 h-4" />
            Clear Audit
          </button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Filter by user, key or license..." 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-full bg-slate-800 border-slate-700 focus:ring-2 focus:ring-blue-500 rounded-xl pl-10 pr-4 py-2 text-sm outline-none transition-all"
            />
          </div>
          <button className="flex items-center gap-2 px-3 py-2 text-slate-400 hover:text-white transition-colors">
            <Filter className="w-4 h-4" />
            <span className="text-sm font-medium">Advanced Filter</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-800/50 border-b border-slate-800">
              <tr>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Timestamp</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">User Details</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">License Applied</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500">Hardware Key</th>
                <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-slate-500 text-center">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <p className="text-sm font-medium">{new Date(log.timestamp).toLocaleDateString()}</p>
                    <p className="text-xs text-slate-500">{new Date(log.timestamp).toLocaleTimeString()}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-bold text-xs text-slate-300">
                        {log.username[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{log.username}</p>
                        <p className="text-xs text-slate-500">IP: {log.ip}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">{log.licencia}</td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-500">{log.key}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                      log.status === 'success' 
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      {log.status === 'success' ? 'Authorized' : 'Rejected'}
                    </span>
                  </td>
                </tr>
              ))}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-500 italic">
                    No logs matching your search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AuthLogs;
