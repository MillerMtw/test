
import React from 'react';
import { Trash2, ShieldCheck, ShieldX, User, Clock, Key, Lock } from 'lucide-react';
import { CredentialEntry } from '../types';

interface UserManagerProps {
  users: CredentialEntry[];
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  searchTerm?: string;
}

const UserManager: React.FC<UserManagerProps> = ({ users, onToggle, onDelete, searchTerm = '' }) => {
  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="mb-12">
        <h2 className="text-5xl font-black tracking-tighter uppercase text-white leading-none">CLIENTS</h2>
        <p className="text-zinc-600 font-black text-[10px] uppercase tracking-widest mt-3">SECTION: CLIENT ADMINISTRATION</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-8">
        {users.map((user, index) => (
          <div key={user.id} className="bg-zinc-950/40 border border-white/5 rounded-[3rem] p-10 shadow-2xl relative group transition-all duration-500 backdrop-blur-xl animate-in slide-in-from-bottom-4" style={{ animationDelay: `${index * 50}ms` }}>
            {/* Cabecera de la tarjeta: Icono Izquierda, Botones Derecha */}
            <div className="flex items-start justify-between mb-8">
              <div className="w-14 h-14 bg-black/60 rounded-2xl border border-white/5 flex items-center justify-center shadow-inner group-hover:border-red-500/20 transition-all duration-500">
                <User className="w-6 h-6 text-red-600" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => onToggle(user.id)} className={`p-3 rounded-2xl transition-all duration-300 ${user.isActive ? 'text-amber-500 bg-amber-500/10 border border-amber-500/10 hover:bg-amber-500/20' : 'text-emerald-500 bg-emerald-500/10 border border-emerald-500/10 hover:bg-emerald-500/20'}`}>
                  {user.isActive ? <ShieldX className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
                </button>
                <button onClick={() => onDelete(user.id)} className="p-3 bg-red-600/10 text-red-600 border border-red-500/10 hover:bg-red-600 hover:text-white rounded-2xl transition-all duration-300">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            {/* Cuerpo de la tarjeta */}
            <div className="space-y-8">
              <div>
                <p className="text-[9px] font-black text-zinc-600 uppercase mb-2 tracking-widest">CLIENT ID</p>
                <h3 className="text-3xl font-black text-white tracking-tighter uppercase">{user.username}</h3>
              </div>
              
              <div className="space-y-5">
                {/* License Key Box */}
                <div className="bg-black/60 border border-white/5 rounded-[1.5rem] p-6 group-hover:border-red-600/10 transition-all duration-500">
                  <div className="flex items-center gap-2 mb-3 opacity-60">
                    <Key className="w-3.5 h-3.5 text-red-600" />
                    <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">LICENSE KEY</span>
                  </div>
                  <p className="text-[12px] font-mono text-zinc-400 truncate font-black tracking-tight">{user.key}</p>
                </div>

                {/* Password Box */}
                {user.password && (
                  <div className="bg-black/60 border border-white/5 rounded-[1.5rem] p-6 group-hover:border-red-600/10 transition-all duration-500">
                    <div className="flex items-center gap-2 mb-3 opacity-60">
                      <Lock className="w-3.5 h-3.5 text-red-600" />
                      <span className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">PASSWORD</span>
                    </div>
                    <p className="text-[12px] font-mono text-zinc-400 truncate font-black tracking-tight">{user.password}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Footer de la tarjeta */}
            <div className="mt-10 pt-8 border-t border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-zinc-800">
                <Clock className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-normal">{new Date(user.timestamp).toLocaleDateString()}</span>
              </div>
              <div className={`px-5 py-2 rounded-full text-[9px] font-black uppercase tracking-widest ${user.isActive ? 'bg-emerald-600/10 text-emerald-500' : 'bg-red-600/10 text-red-600'}`}>
                {user.isActive ? 'ACTIVE' : 'DISABLED'}
              </div>
            </div>
          </div>
        ))}
        
        {users.length === 0 && (
          <div className="col-span-full py-32 text-center border-2 border-dashed border-white/5 rounded-[4rem] backdrop-blur-xl bg-zinc-950/20">
            <ShieldX className="w-20 h-20 text-zinc-900 mx-auto mb-6 opacity-20" />
            <h3 className="text-2xl font-black uppercase text-zinc-800 tracking-tighter">DATA SILENT</h3>
            <p className="text-[11px] font-bold text-zinc-800 uppercase tracking-widest mt-2">NO CLIENTS VERIFIED</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserManager;
