
import React, { useState } from 'react';
import { Plus, Trash2, Key, CheckCircle, XCircle, MoreVertical, Copy, Search } from 'lucide-react';
import { License } from '../types';

interface LicenseManagerProps {
  licenses: License[];
  onAdd: (license: License) => void;
  onDelete: (id: string) => void;
  onToggle: (id: string) => void;
}

const LicenseManager: React.FC<LicenseManagerProps> = ({ licenses, onAdd, onDelete, onToggle }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLicense, setNewLicense] = useState({ owner: '', type: 'Standard' as License['type'] });

  const handleCreate = () => {
    if (!newLicense.owner) return;
    
    const prefix = newLicense.type === 'Developer' ? 'DEV' : newLicense.type === 'Premium' ? 'PRM' : 'STD';
    const randomKey = `${prefix}-${Math.random().toString(36).substring(2, 5).toUpperCase()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    
    onAdd({
      id: Math.random().toString(36).substring(2, 9),
      key: randomKey,
      owner: newLicense.owner,
      expiryDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 365).toISOString().split('T')[0], // 1 year
      isActive: true,
      type: newLicense.type
    });
    
    setShowAddModal(false);
    setNewLicense({ owner: '', type: 'Standard' });
  };

  return (
    <div className="space-y-6 animate-in zoom-in-95 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">License Vault</h1>
          <p className="text-slate-400">Manage and issue access keys for your Roblox scripts.</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl transition-all shadow-lg shadow-blue-600/30 font-bold"
        >
          <Plus className="w-5 h-5" />
          Generate New
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {licenses.map((lic) => (
          <div key={lic.id} className={`bg-slate-900 border ${lic.isActive ? 'border-slate-800' : 'border-rose-900/50 opacity-75'} rounded-2xl p-6 relative overflow-hidden group shadow-xl transition-all hover:scale-[1.02]`}>
            {!lic.isActive && (
              <div className="absolute top-2 right-2 px-2 py-0.5 bg-rose-500 text-[10px] font-black uppercase rounded text-white z-10">Suspended</div>
            )}
            
            <div className="flex items-start justify-between mb-6">
              <div className={`p-3 rounded-2xl ${lic.isActive ? 'bg-blue-600/10 text-blue-400' : 'bg-slate-800 text-slate-500'}`}>
                <Key className="w-6 h-6" />
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => onToggle(lic.id)}
                  className={`p-2 rounded-xl transition-colors ${lic.isActive ? 'hover:bg-amber-500/10 text-slate-600 hover:text-amber-500' : 'hover:bg-emerald-500/10 text-slate-600 hover:text-emerald-500'}`}
                  title={lic.isActive ? "Deactivate" : "Activate"}
                >
                  {lic.isActive ? <XCircle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
                </button>
                <button 
                  onClick={() => onDelete(lic.id)}
                  className="p-2 hover:bg-rose-500/10 text-slate-600 hover:text-rose-500 rounded-xl transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Owner</p>
                <h3 className="text-lg font-bold">{lic.owner}</h3>
              </div>
              
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-wider mb-1">Key Code</p>
                <div className="flex items-center justify-between bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 group/code">
                  <code className="text-xs text-blue-400 font-mono tracking-tighter">{lic.key}</code>
                  <button onClick={() => navigator.clipboard.writeText(lic.key)} className="opacity-0 group-hover/code:opacity-100 transition-opacity">
                    <Copy className="w-3 h-3 text-slate-400 hover:text-white" />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <div>
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Tier</p>
                  <span className={`text-xs font-bold ${
                    lic.type === 'Developer' ? 'text-amber-400' : lic.type === 'Premium' ? 'text-purple-400' : 'text-slate-400'
                  }`}>{lic.type}</span>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-slate-500 font-bold uppercase">Expires</p>
                  <p className="text-xs text-slate-300">{lic.expiryDate}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add License Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl shadow-2xl p-8 animate-in zoom-in-95 duration-300">
            <h2 className="text-2xl font-bold mb-6">Issue New License</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1.5">Owner Name</label>
                <input 
                  type="text" 
                  placeholder="e.g. RobloxUser_123" 
                  value={newLicense.owner}
                  onChange={(e) => setNewLicense({ ...newLicense, owner: e.target.value })}
                  className="w-full bg-slate-800 border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1.5">License Tier</label>
                <select 
                  value={newLicense.type}
                  onChange={(e) => setNewLicense({ ...newLicense, type: e.target.value as License['type'] })}
                  className="w-full bg-slate-800 border-slate-700 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                >
                  <option value="Standard">Standard</option>
                  <option value="Premium">Premium</option>
                  <option value="Developer">Developer</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3 mt-8">
              <button 
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl font-bold transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleCreate}
                className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl font-bold transition-colors shadow-lg shadow-blue-600/20"
              >
                Create Key
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LicenseManager;
