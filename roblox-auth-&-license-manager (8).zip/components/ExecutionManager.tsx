
import React from 'react';
import { Activity, Terminal, Globe, Cpu, ShieldCheck, ShieldAlert } from 'lucide-react';
import { ExecutionLog } from '../types';

interface ExecutionManagerProps {
  logs: ExecutionLog[];
}

const ExecutionManager: React.FC<ExecutionManagerProps> = ({ logs }) => {
  return (
    <div className="space-y-10 animate-in slide-in-from-bottom-6 duration-700">
      <div>
        <h2 className="text-4xl font-black tracking-tighter uppercase text-white">HISTORY LOGS</h2>
        <p className="text-zinc-600 font-bold text-[10px] uppercase tracking-widest mt-1">REMOTE SECURITY AUDIT TRAIL</p>
      </div>

      <div className="bg-black border border-zinc-900 rounded-[2.5rem] shadow-2xl overflow-hidden relative">
        <div className="p-8 border-b border-zinc-900 bg-zinc-900/10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-2xl bg-zinc-950 flex items-center justify-center border border-zinc-900 shadow-inner">
              <Terminal className="w-5 h-5 text-red-600" />
            </div>
            <h3 className="text-sm font-black uppercase tracking-widest text-white">CORE REGISTRY</h3>
          </div>
          <div className="px-4 py-2 bg-zinc-950 rounded-xl border border-zinc-900 text-[10px] font-black uppercase text-zinc-500">
            CYCLES: {logs.length}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-black border-b border-zinc-900">
                <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-zinc-600">Timestamp</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-zinc-600">Target</th>
                <th className="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-zinc-600 text-center">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-950">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-red-600/5 transition-all group">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-zinc-950 rounded-lg group-hover:border-red-500/20 border border-zinc-900"><Cpu className="w-3.5 h-3.5 text-zinc-700 group-hover:text-red-600 transition-colors" /></div>
                      <div>
                        <p className="text-[11px] font-black tracking-tight text-white">{new Date(log.timestamp).toLocaleDateString()}</p>
                        <p className="text-[9px] font-bold text-zinc-700 uppercase">{new Date(log.timestamp).toLocaleTimeString()}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <p className="text-[11px] font-black uppercase tracking-tight text-zinc-300">{log.username}</p>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex justify-center">
                      <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-[9px] font-black uppercase border ${
                        log.status === 'Authorized' 
                          ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' 
                          : 'bg-red-600/10 text-red-600 border-red-500/20'
                      }`}>
                        {log.status === 'Authorized' ? <ShieldCheck className="w-3 h-3" /> : <ShieldAlert className="w-3 h-3" />}
                        {log.status}
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
              {logs.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-8 py-20 text-center">
                    <Activity className="w-12 h-12 text-zinc-900 mx-auto mb-4 opacity-10" />
                    <p className="text-[10px] font-black uppercase text-zinc-900 tracking-widest">TELEMETRY_SILENT</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ExecutionManager;
