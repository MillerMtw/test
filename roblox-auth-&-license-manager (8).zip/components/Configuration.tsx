
import React, { useState } from 'react';
import { 
  Globe, 
  Lock, 
  Save, 
  CheckCircle2, 
  Database,
  Key
} from 'lucide-react';
import { AppConfig } from '../types';

interface ConfigurationProps {
  config: AppConfig;
  onUpdate: (config: AppConfig) => void;
  isOwner: boolean;
}

const Configuration: React.FC<ConfigurationProps> = ({ config, onUpdate, isOwner }) => {
  const [localConfig, setLocalConfig] = useState<AppConfig>(config);
  const [status, setStatus] = useState<'idle' | 'saving' | 'success'>('idle');

  const handleSave = () => {
    setStatus('saving');
    setTimeout(() => {
      onUpdate(localConfig);
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-10 duration-700 pb-20">
      <div>
        <h2 className="text-3xl font-black tracking-tighter uppercase text-white leading-none">SYSTEM SETTINGS</h2>
        <p className="text-zinc-600 font-bold text-[8px] uppercase tracking-widest mt-2">CORE CONFIGURATION</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <section className="bg-zinc-950/40 border border-white/5 rounded-[2rem] p-8 md:p-10 shadow-2xl backdrop-blur-xl space-y-8">
          <div className="flex items-center gap-4 border-b border-white/5 pb-6">
            <div className="p-3 bg-red-600/10 rounded-2xl border border-red-500/10"><Globe className="w-6 h-6 text-red-600" /></div>
            <h3 className="text-sm font-black uppercase tracking-widest text-white">CONNECTIVITY GATEWAY</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-2">
              <label className="text-[9px] font-black uppercase tracking-widest text-zinc-600 ml-1">API URL (ENDPOINT)</label>
              <div className={`relative group ${!isOwner ? 'opacity-50' : ''}`}>
                <Globe className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${isOwner ? 'text-zinc-700 group-focus-within:text-red-500' : 'text-zinc-800'}`} />
                <input 
                  type="text" 
                  value={localConfig.apiEndpoint} 
                  disabled={!isOwner}
                  onChange={(e) => setLocalConfig({...localConfig, apiEndpoint: e.target.value})}
                  className="w-full bg-black/40 border border-white/5 rounded-2xl pl-12 pr-6 py-4 outline-none font-mono text-[11px] font-bold text-white transition-all focus:ring-1 ring-red-500/30" 
                  placeholder="https://your-api.com/exec"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[9px] font-black uppercase tracking-widest text-zinc-600 ml-1">API KEY (DZisthegoat)</label>
              <div className="relative group">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-700 group-focus-within:text-red-500 transition-colors" />
                <input 
                  type="password" 
                  value={localConfig.apiSecret} 
                  placeholder="••••••••" 
                  onChange={(e) => setLocalConfig({...localConfig, apiSecret: e.target.value})} 
                  className="w-full bg-black/40 border border-white/5 rounded-2xl pl-12 pr-6 py-4 outline-none focus:ring-1 ring-red-500/30 font-mono text-[11px] font-bold text-white" 
                />
              </div>
            </div>
          </div>
        </section>
      </div>

      <div className="bg-zinc-950/20 border border-white/5 rounded-[2.5rem] p-10 shadow-2xl flex flex-col sm:flex-row items-center justify-between gap-8 backdrop-blur-xl relative overflow-hidden group">
        <div className="flex items-center gap-6 text-center sm:text-left relative z-10">
          <div className="p-4 bg-red-600/10 rounded-3xl border border-red-500/20"><Database className="w-8 h-8 text-red-600" /></div>
          <div>
            <h3 className="text-xl font-black uppercase tracking-tight text-white leading-none">PERSIST CHANGES</h3>
            <p className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest mt-1.5">SAVE SYSTEM CONFIGURATION</p>
          </div>
        </div>
        <button 
          onClick={handleSave} 
          disabled={status === 'saving' || !isOwner} 
          className={`w-full sm:w-auto px-12 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-3 relative z-10 shadow-2xl ${
            status === 'success' ? 'bg-emerald-600 text-white' : 
            isOwner ? 'bg-red-600 text-white hover:bg-red-700 hover:scale-[1.02] active:scale-95 shadow-red-600/30 border border-red-500/20' : 
            'bg-zinc-800 text-zinc-500 cursor-not-allowed border-zinc-700/30'
          }`}
        >
          {status === 'saving' ? (
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : status === 'success' ? (
            <CheckCircle2 className="w-5 h-5" />
          ) : (
            <Save className="w-5 h-5" />
          )}
          {status === 'saving' ? 'UPDATING...' : status === 'success' ? 'SYSTEM UPDATED' : 'SAVE SETTINGS'}
        </button>
      </div>
    </div>
  );
};

export default Configuration;
