
import React, { useState } from 'react';
import { Play, Send, Code, Terminal as TerminalIcon, Info } from 'lucide-react';
import { AuthRequest } from '../types';

interface ScriptSimulatorProps {
  onSend: (data: Omit<AuthRequest, 'id' | 'timestamp' | 'status'>) => void;
}

const ScriptSimulator: React.FC<ScriptSimulatorProps> = ({ onSend }) => {
  const [formData, setFormData] = useState({
    username: 'Guest_User',
    key: 'HWID-' + Math.random().toString(36).substring(7).toUpperCase(),
    licencia: ''
  });
  const [sending, setSending] = useState(false);
  const [lastResponse, setLastResponse] = useState<string | null>(null);

  const simulateSend = () => {
    setSending(true);
    setLastResponse(null);
    
    setTimeout(() => {
      onSend(formData);
      setSending(false);
      setLastResponse('Success: POST request emitted to virtual endpoint.');
    }, 800);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <TerminalIcon className="w-8 h-8 text-blue-500" />
            Script Simulator
          </h1>
          <p className="text-slate-400">Test your authentication API with mock Roblox data payloads.</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-xs font-bold">
          <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
          VIRTUAL SERVER: ONLINE
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Controls (The GUI) */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="flex items-center gap-2 mb-8 p-3 bg-slate-800/50 border border-slate-700 rounded-xl">
            <Info className="w-5 h-5 text-blue-400" />
            <p className="text-xs text-slate-300">This form mimics your Roblox <b>ScreenGui</b> logic.</p>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2">Username</label>
              <input 
                type="text" 
                value={formData.username}
                onChange={(e) => setFormData({...formData, username: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2">Hardware ID Key</label>
              <input 
                type="text" 
                value={formData.key}
                onChange={(e) => setFormData({...formData, key: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2">Licencia</label>
              <input 
                type="text" 
                placeholder="Paste key (e.g. DEV-XYZ...)"
                value={formData.licencia}
                onChange={(e) => setFormData({...formData, licencia: e.target.value})}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all font-mono"
              />
            </div>

            <button 
              onClick={simulateSend}
              disabled={sending}
              className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-bold text-lg transition-all shadow-xl ${
                sending ? 'bg-slate-800 text-slate-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30'
              }`}
            >
              {sending ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  Execute HttpPostAsync
                </>
              )}
            </button>

            {lastResponse && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs font-medium text-center animate-in fade-in slide-in-from-bottom-2">
                {lastResponse}
              </div>
            )}
          </div>
        </div>

        {/* Code Snippet Info */}
        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-3xl">
            <h3 className="text-lg font-bold flex items-center gap-2 mb-4">
              <Code className="w-5 h-5 text-indigo-400" />
              Roblox Snippet Reference
            </h3>
            <pre className="text-[10px] bg-slate-950 p-4 rounded-xl border border-slate-800 text-slate-400 font-mono overflow-x-auto">
{`local data = {
  ["Username"] = UserInput.Text,
  ["Key"] = KeyInput.Text,
  ["Licencia"] = LicInput.Text
}

local result = HttpService:PostAsync(
  "http://api.domain.com/auth",
  HttpService:JSONEncode(data),
  Enum.HttpContentType.ApplicationJson
)`}
            </pre>
            <p className="text-xs text-slate-500 mt-4 leading-relaxed">
              When the button above is clicked, the simulator generates a JSON body identical to your Roblox code and emits it to the internal logging service.
            </p>
          </div>

          <div className="p-6 bg-gradient-to-br from-indigo-600 to-blue-700 rounded-3xl shadow-xl shadow-blue-900/20 text-white">
            <h3 className="font-bold mb-2">Pro Tip: Security</h3>
            <p className="text-sm opacity-90 leading-relaxed mb-4">
              Never send raw licenses over HTTP. Use HTTPS and consider signing your requests with a secret key derived from your HWID for maximum security.
            </p>
            <button className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl text-sm font-bold transition-all border border-white/20">
              Read Security Docs
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScriptSimulator;
