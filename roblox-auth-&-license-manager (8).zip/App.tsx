
import React, { useState, useEffect, useCallback } from 'react';
import { 
  LayoutDashboard, 
  Settings as SettingsIcon, 
  LogOut,
  Menu,
  X,
  LogIn,
  Star,
  Activity
} from 'lucide-react';
import { DashboardTab, CredentialEntry, ExecutionLog, AppConfig, AuthSession } from './types';
import Overview from './components/Overview';
import Configuration from './components/Configuration';

const VALID_USERS = [
  { username: 'therealroier', password: '260211!!!', role: 'OWNER' },
  { username: 'Damiancito', password: 'DzOnTop', role: 'ADMIN' }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<DashboardTab>(DashboardTab.OVERVIEW);
  const [rememberMe, setRememberMe] = useState(true);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [apiOnline, setApiOnline] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  const [session, setSession] = useState<AuthSession>(() => {
    const saved = localStorage.getItem('master_session');
    return saved ? JSON.parse(saved) : { username: 'Guest', isLoggedIn: true, lastVisit: new Date().toISOString() };
  });

  const [setupForm, setSetupForm] = useState({ username: '', password: '' });
  const [authError, setAuthError] = useState('');

  const [config, setConfig] = useState<AppConfig>(() => {
    const saved = localStorage.getItem('master_auth_config');
    const defaultApi = 'https://api-v7-0b4d.onrender.com/exec';
    const defaultKey = 'DZisthegoat';
    if (saved) {
      return JSON.parse(saved);
    }
    return {
      apiEndpoint: defaultApi,
      apiSecret: defaultKey,
      webhookUrl: ''
    };
  });

  const [users, setUsers] = useState<CredentialEntry[]>([]);
  const [logs, setLogs] = useState<ExecutionLog[]>([]);

  const isGuest = session.username === 'Guest';
  const currentUserData = VALID_USERS.find(u => u.username === session.username);
  const displayRole = isGuest ? 'INVITED' : (currentUserData?.role || 'ADMIN');
  const actualIsOwner = displayRole === 'OWNER';

  const apiCall = useCallback(async (action: string, body: any = {}) => {
    if (!config.apiEndpoint) {
        setApiOnline(false);
        return null;
    }
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const headers: HeadersInit = {
        'Content-Type': 'application/json'
      };
      
      if (config.apiSecret) {
        headers['Authorization'] = `Bearer ${config.apiSecret}`;
        headers['x-api-key'] = config.apiSecret;
      }

      const response = await fetch(config.apiEndpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ action, ...body }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!response.ok) {
          setApiOnline(false);
          return null;
      }
      const data = await response.json();
      setApiOnline(true);
      return data;
    } catch (err) {
      setApiOnline(false);
      return null;
    }
  }, [config.apiEndpoint, config.apiSecret]);

  const syncFromApi = useCallback(async () => {
    const data = await apiCall('fetch_all');
    if (data) {
      if (data.users) setUsers(data.users);
      if (data.logs) setLogs(data.logs);
    }
  }, [apiCall]);

  useEffect(() => {
    if (session.isLoggedIn && config.apiEndpoint) {
      syncFromApi();
      const interval = setInterval(syncFromApi, 2000);
      return () => clearInterval(interval);
    }
    const pingInterval = setInterval(() => apiCall('ping'), 5000);
    return () => clearInterval(pingInterval);
  }, [session.isLoggedIn, config.apiEndpoint, syncFromApi, apiCall]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    const user = VALID_USERS.find(u => u.username === setupForm.username && u.password === setupForm.password);
    if (user) {
      const newSession = { username: user.username, isLoggedIn: true, lastVisit: new Date().toISOString() };
      setSession(newSession);
      if (rememberMe) localStorage.setItem('master_session', JSON.stringify(newSession));
      setShowAuthModal(false);
      setSetupForm({ username: '', password: '' });
    } else {
      setAuthError('Invalid credentials');
    }
  };

  const handleLogOut = useCallback(() => {
    const guestSession = { username: 'Guest', isLoggedIn: true, lastVisit: new Date().toISOString() };
    setSession(guestSession);
    localStorage.removeItem('master_session');
    setActiveTab(DashboardTab.OVERVIEW);
  }, []);

  const handleUpdateConfig = (newConfig: AppConfig) => {
    setConfig(newConfig);
    localStorage.setItem('master_auth_config', JSON.stringify(newConfig));
  };

  return (
    <div className="flex h-screen bg-black text-zinc-300 overflow-hidden relative font-sans">
      
      {showAuthModal && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/80 backdrop-blur-3xl animate-in fade-in duration-500">
          <div className="w-full max-w-md bg-zinc-950/60 border border-white/5 p-8 rounded-[2rem] shadow-2xl relative animate-in zoom-in-95 duration-500 overflow-hidden backdrop-blur-2xl">
            <button onClick={() => setShowAuthModal(false)} className="absolute top-6 right-6 text-zinc-500 hover:text-white transition-colors z-20"><X className="w-5 h-5" /></button>
            <div className="flex flex-col items-center mb-8 text-center relative z-20">
              <div className="bg-red-600 w-12 h-12 rounded-2xl mb-4 shadow-2xl border border-red-400/20 flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-400 fill-yellow-400" />
              </div>
              <h1 className="text-3xl font-black text-white uppercase tracking-tighter">ILLUXION</h1>
              <p className="text-red-600 text-[10px] font-black mt-1 uppercase tracking-[0.3em]">SECURITY SYSTEM</p>
            </div>
            <form onSubmit={handleAuth} className="space-y-4 relative z-20">
              <div className="space-y-1.5">
                <label className="text-[8px] font-bold uppercase tracking-widest text-zinc-600 ml-1">USERNAME</label>
                <input type="text" required placeholder="User" value={setupForm.username} onChange={(e) => setSetupForm({...setupForm, username: e.target.value})} className="w-full bg-black/40 border border-white/5 rounded-xl px-5 py-3 outline-none focus:ring-1 ring-red-500/50 transition-all font-medium text-xs text-white placeholder-zinc-800" />
              </div>
              <div className="space-y-1.5">
                <label className="text-[8px] font-bold uppercase tracking-widest text-zinc-600 ml-1">Password</label>
                <input type="password" required placeholder="••••••••" value={setupForm.password} onChange={(e) => setSetupForm({...setupForm, password: e.target.value})} className="w-full bg-black/40 border border-white/5 rounded-xl px-5 py-3 outline-none focus:ring-1 ring-red-500/50 transition-all font-medium text-xs text-white placeholder-zinc-800" />
              </div>
              {authError && <p className="text-red-500 text-[8px] font-bold text-center uppercase tracking-normal">{authError}</p>}
              <button type="submit" className="w-full py-3.5 bg-red-600 hover:bg-red-700 text-white font-black uppercase tracking-widest text-[9px] rounded-xl shadow-lg transition-all active:scale-95 mt-2">AUTHENTICATE</button>
            </form>
          </div>
        </div>
      )}

      {/* Sidebar - MARCA REORGANIZADA E INDICADOR SYSTEM REUBICADO */}
      <aside className={`fixed lg:static inset-y-0 left-0 w-72 bg-transparent flex flex-col z-[100] transition-transform duration-500 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-8 pt-10">
          <div className="flex items-center gap-5">
            <div className="bg-[#e62117] w-12 h-12 rounded-2xl shadow-[0_8px_25px_rgba(230,33,23,0.3)] flex items-center justify-center shrink-0 border border-white/5">
              <Star className="w-6 h-6 text-[#fbbf24] fill-[#fbbf24]" />
            </div>
            <div className="flex flex-col">
              <h1 className="font-black text-2xl text-white uppercase tracking-tighter leading-none">ILLUXION</h1>
              <p className="text-[9px] text-red-600 font-black uppercase tracking-[0.2em] mt-1.5">SECURITY SYSTEM</p>
            </div>
          </div>
        </div>
        
        <nav className="flex-1 px-4 space-y-2 mt-8">
          <NavItem icon={<LayoutDashboard className="w-5 h-5" />} label="DASHBOARD" active={activeTab === DashboardTab.OVERVIEW} onClick={() => {setActiveTab(DashboardTab.OVERVIEW); setIsSidebarOpen(false);}} />
          {actualIsOwner && !isGuest && <NavItem icon={<SettingsIcon className="w-5 h-5" />} label="SETTINGS" active={activeTab === DashboardTab.SETTINGS} onClick={() => {setActiveTab(DashboardTab.SETTINGS); setIsSidebarOpen(false);}} />}
        </nav>

        <div className="p-8 mt-auto space-y-4">
          {/* SYSTEM STATUS - REUBICADO AQUÍ ABAJO */}
          <div className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border ${apiOnline ? 'bg-emerald-500/5 border-emerald-500/10' : 'bg-red-500/5 border-red-500/10'} transition-all`}>
            <div className={`w-2 h-2 rounded-full ${apiOnline ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'} animate-pulse`} />
            <span className={`text-[10px] font-black uppercase tracking-widest ${apiOnline ? 'text-emerald-500' : 'text-red-500'}`}>
              SYSTEM {apiOnline ? 'ONLINE' : 'OFFLINE'}
            </span>
          </div>

          <button onClick={isGuest ? () => { setShowAuthModal(true); } : handleLogOut} className="flex items-center gap-4 w-full p-4 hover:bg-white/5 rounded-xl transition-all font-black text-[10px] text-zinc-600 group uppercase tracking-[0.2em]">
            <LogOut className="w-5 h-5 group-hover:text-red-500 transition-colors" />
            <span>{isGuest ? 'LOG IN' : 'LOG OUT'}</span>
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-24 flex items-center z-40 bg-transparent relative">
          <div className="w-full pl-8 pr-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button className="lg:hidden p-3 text-zinc-500 bg-white/5 rounded-xl" onClick={() => setIsSidebarOpen(true)}><Menu className="w-6 h-6" /></button>
            </div>

            {/* Derecha: Bloque de Usuario Limpio */}
            <div className="flex items-center gap-5 ml-auto">
              <div className="text-right leading-[1.1]">
                <p className="text-[16px] font-black text-white tracking-tighter uppercase">{session.username}</p>
                <p className="text-[10px] font-black text-[#ff0000] uppercase tracking-[0.2em] mt-0.5">{displayRole}</p>
              </div>
              <div className="h-11 w-11 rounded-xl bg-[#e62117] flex items-center justify-center shadow-lg border border-red-500/10 transition-transform hover:scale-105">
                <span className="font-black text-white uppercase text-xl tracking-tighter">{session.username[0]}</span>
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-10 custom-scrollbar bg-transparent">
          <div className="max-w-7xl mx-auto">
            {activeTab === DashboardTab.OVERVIEW && <Overview logs={logs} users={users} isOnline={apiOnline} />}
            {activeTab === DashboardTab.SETTINGS && actualIsOwner && !isGuest && <Configuration config={config} onUpdate={handleUpdateConfig} isOwner={actualIsOwner} />}
          </div>
        </div>
      </main>
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: any) => (
  <button 
    onClick={onClick} 
    className={`flex items-center gap-4 w-full px-5 py-3.5 rounded-xl transition-all duration-300 font-black text-[13px] group relative ${active ? 'bg-[#e62117] text-white shadow-[0_5px_20px_rgba(230,33,23,0.25)]' : 'text-zinc-500 hover:text-white hover:bg-white/5'}`}
  >
    <div className={`transition-all duration-500 ${active ? 'scale-110' : 'opacity-70 group-hover:opacity-100'}`}>
      {icon}
    </div>
    <span className="tracking-tight uppercase">{label}</span>
  </button>
);

export default App;
