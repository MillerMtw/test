
export interface CredentialEntry {
  id: string;
  username: string;
  password?: string;
  key: string;
  timestamp: string;
  isActive: boolean;
}

export interface ExecutionLog {
  id: string;
  username: string;
  timestamp: string;
  status: 'Authorized' | 'Unauthorized';
  ip: string;
}

export enum DashboardTab {
  OVERVIEW = 'overview',
  SETTINGS = 'settings'
}

export interface AppConfig {
  apiEndpoint: string;
  apiSecret: string;
  webhookUrl: string;
}

export interface AuthSession {
  username: string;
  isLoggedIn: boolean;
  lastVisit: string;
}

export interface MasterAccount {
  username: string;
  passwordHash: string;
  licenseKey?: string; 
}

export interface AuthRequest {
  id: string;
  timestamp: string;
  username: string;
  ip?: string;
  licencia: string;
  key: string;
  status: 'success' | 'failed';
}

export interface License {
  id: string;
  key: string;
  owner: string;
  expiryDate: string;
  isActive: boolean;
  type: 'Standard' | 'Premium' | 'Developer';
}
